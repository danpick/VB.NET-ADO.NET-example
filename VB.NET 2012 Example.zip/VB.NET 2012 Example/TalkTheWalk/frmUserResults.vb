﻿Public Class frmUserResults

    Private Sub frmUserResults_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        frmUser.Show()
    End Sub

    Private Sub frmUserResults_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        LoadGenericFormSettings(Me)

        'picLogo.Left = 10
        'picLogo.Top = 10
        'lblTitle.Left = 135
        'lblTitle.Top = 10
        'lblWelcome.Left = 335
        'lblWelcome.Top = 10
        lblWelcome.Text = gsWelcomeText
        lblTitle.Text = "Test Results"
        lvUserResults.View = View.Details

        LoadResults()

    End Sub

    Private Sub LoadResults()

        Dim sSQL As String
        Dim lvi As ListViewItem
        Dim sDateToDisplay As String
        Dim sTimeToDisplay As String

        lvUserResults.Columns.Add("Date/Time", 150)
        lvUserResults.Columns.Add("Area", 150)
        lvUserResults.Columns.Add("Score", 50)


        sSQL = "SELECT tblUserResults.dtDate, "
        sSQL = sSQL & "tblUserResults.dtTime, "
        sSQL = sSQL & "tblAreas.tAreaName, "
        sSQL = sSQL & "tblUserResults.nbtScore "
        sSQL = sSQL & "FROM tblAreas "
        sSQL = sSQL & "INNER JOIN tblUserResults "
        sSQL = sSQL & "ON tblAreas.niAreaID = tblUserResults.niAreaID "
        sSQL = sSQL & "WHERE tblUserResults.tUserName = '" & gsLoggedOnUsername & "' "
        sSQL = sSQL & "ORDER BY tblUserResults.dtDate DESC, "
        sSQL = sSQL & "tblUserResults.dtTime DESC"

        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "UserResults")

        gsResultsHTML = ""
        lvUserResults.Items.Clear()
        For i = 0 To gdsData.Tables("UserResults").Rows.Count - 1
            sDateToDisplay = Format(gdsData.Tables("UserResults").Rows(i).Item("dtDate"), "dd/MM/yyyy")
            sTimeToDisplay = Format(gdsData.Tables("UserResults").Rows(i).Item("dtTime"), "HH:mm:ss")
            lvi = lvUserResults.Items.Add(sDateToDisplay & " " & sTimeToDisplay)
            lvi.SubItems.Add(gdsData.Tables("UserResults").Rows(i).Item("tAreaName"))
            lvi.SubItems.Add(gdsData.Tables("UserResults").Rows(i).Item("nbtScore"))

            gsResultsHTML = gsResultsHTML & "<tr>"
            gsResultsHTML = gsResultsHTML & "<td>"
            gsResultsHTML = gsResultsHTML & sDateToDisplay & " " & sTimeToDisplay
            gsResultsHTML = gsResultsHTML & "</td>"
            gsResultsHTML = gsResultsHTML & "<td>"
            gsResultsHTML = gsResultsHTML & gdsData.Tables("UserResults").Rows(i).Item("tAreaName")
            gsResultsHTML = gsResultsHTML & "</td>"
            gsResultsHTML = gsResultsHTML & "<td>"
            gsResultsHTML = gsResultsHTML & gdsData.Tables("UserResults").Rows(i).Item("nbtScore")
            gsResultsHTML = gsResultsHTML & "</td>"
            gsResultsHTML = gsResultsHTML & "</tr>"

        Next i

        gdsData.Tables("UserResults").Reset()


    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click

        Me.Close()

    End Sub

    Private Sub cmdPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPrint.Click
        gPrintResults("User")
    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class