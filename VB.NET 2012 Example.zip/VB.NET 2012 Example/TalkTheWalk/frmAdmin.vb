﻿Public Class frmAdmin

    Private Sub frmAdmin_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        End
    End Sub

    Private Sub frmAdmin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        LoadGenericFormSettings(Me)

        'picLogo.Left = 10
        'picLogo.Top = 10
        'lblTitle.Left = 135
        'lblTitle.Top = 10
        'lblWelcome.Left = 335
        'lblWelcome.Top = 10

        lblWelcome.Text = gsWelcomeText
        lblTitle.Text = "Admin"

    End Sub


    Private Sub cmdUserManagement_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUserManagement.Click

        frmAdminUserMgmt.Show()
        Me.Hide()

    End Sub

    Private Sub cmdQuizManagement_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdQuizManagement.Click

        frmAdminQuizMgmt.Show()
        Me.Hide()

    End Sub

    Private Sub cmdResults_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdResults.Click

        frmAdminResults.Show()
        Me.Hide()

    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class