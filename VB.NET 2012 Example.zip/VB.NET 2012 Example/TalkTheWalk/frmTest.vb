﻿Public Class frmTest

    Const NoOfQuestionsInTest = 10
    Dim miTestScore As Integer
    Dim miQuestionsAsked As Integer
    Dim miTestAreaID As Integer
    Dim msClosingRoute As String

    Private Sub frmTest_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        If msClosingRoute = "TestComplete" Then
            frmUserResults.Show()
        Else
            frmUser.Show()
        End If

    End Sub

    Private Sub frmTest_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        LoadGenericFormSettings(Me)

        'picLogo.Left = 10
        'picLogo.Top = 5
        'lblTitle.Left = 135
        'lblTitle.Top = 5
        'lblWelcome.Left = 335
        'lblWelcome.Top = 5

        lblWelcome.Text = gsWelcomeText
        lblTitle.Text = "Test"
        cboAreas.DropDownStyle = ComboBoxStyle.DropDownList
        picCorrect.SizeMode = PictureBoxSizeMode.StretchImage
        picWrong1.SizeMode = PictureBoxSizeMode.StretchImage
        picWrong2.SizeMode = PictureBoxSizeMode.StretchImage
        picWrong3.SizeMode = PictureBoxSizeMode.StretchImage
        picCorrect.Visible = False
        picWrong1.Visible = False
        picWrong2.Visible = False
        picWrong3.Visible = False
        lblQuestion.Text = ""
        lblResult.Text = ""

        gPopulateAreasCombo(Me)

    End Sub

    Private Sub cmdAccountSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        frmAccountSettings.Show()
        Me.Hide()

    End Sub

    'Private Sub PopulateAreasCombo()

    '    Dim sSQL As String
    '    Dim iAreaID As Integer
    '    Dim sAreaName As String

    '    'cboAreas.ResetText()
    '    'cboAreas.Items.Clear()

    '    sSQL = "SELECT niAreaID, tAreaName FROM tblAreas ORDER BY tAreaName ASC"
    '    gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
    '    gda.Fill(gdsData, "Areas")

    '    For i = 0 To gdsData.Tables("Areas").Rows.Count - 1
    '        iAreaID = gdsData.Tables("Areas").Rows(i).Item("niAreaID")
    '        sAreaName = gdsData.Tables("Areas").Rows(i).Item("tAreaName")
    '        cboAreas.Items.Add(New ValueDescriptionPair(iAreaID, sAreaName))
    '    Next i

    'End Sub

    Private Sub cboAreas_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboAreas.SelectedIndexChanged

        ResetTestQuestions()
        SelectRandomTestQuestion()

    End Sub

    Private Sub ResetTestQuestions()

        Dim sSql As String
        Dim cmd As OleDb.OleDbCommand 'required locally

        'new test session
        sSql = "UPDATE tblQuestions SET bAskedInTest = No"
        cmd = New OleDb.OleDbCommand(sSql, gCon)
        cmd.ExecuteNonQuery()

    End Sub

    Private Sub SelectRandomTestQuestion()

        Dim sSQL As String
        Dim sQuestionID As String
        Dim sAreaID As String
        Dim iRandom As Integer = 0
        Dim cmd As OleDb.OleDbCommand 'required locally

        miTestAreaID = CType(cboAreas.SelectedItem, ValueDescriptionPair).Value
        sAreaID = Format(miTestAreaID, "000")

        sSQL = "SELECT niQuestionID, "
        sSQL = sSQL & "tQuestionText "
        sSQL = sSQL & "FROM tblQuestions "
        sSQL = sSQL & "WHERE niAreaID = " & miTestAreaID & " "
        sSQL = sSQL & "AND bAskedInTest = No "
        sSQL = sSQL & "ORDER BY Rnd([niQuestionID])"
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "PractiseQuestions")

        miQuestionsAsked = miQuestionsAsked + 1
        lblTitle.Text = "Test Question " & miQuestionsAsked & "/10"
        sQuestionID = Format(gdsData.Tables("PractiseQuestions").Rows(0).Item("niQuestionID"), "000")

        sSQL = "UPDATE tblQuestions SET bAskedInTest = Yes WHERE niQuestionID = " & sQuestionID
        cmd = New OleDb.OleDbCommand(sSQL, gCon)
        cmd.ExecuteNonQuery()

        'next four blocks could be condensed into a loop, but would require a control array
        lblQuestion.Text = gdsData.Tables("PractiseQuestions").Rows(0).Item("tQuestionText")
        picCorrect.Image = Image.FromFile(gsAppPath & "\" & sAreaID & "\" & sQuestionID & ".png")

        sQuestionID = Format(gdsData.Tables("PractiseQuestions").Rows(1).Item("niQuestionID"), "000")
        picWrong1.Image = Image.FromFile(gsAppPath & "\" & sAreaID & "\" & sQuestionID & ".png")

        sQuestionID = Format(gdsData.Tables("PractiseQuestions").Rows(2).Item("niQuestionID"), "000")
        picWrong2.Image = Image.FromFile(gsAppPath & "\" & sAreaID & "\" & sQuestionID & ".png")

        sQuestionID = Format(gdsData.Tables("PractiseQuestions").Rows(3).Item("niQuestionID"), "000")
        picWrong3.Image = Image.FromFile(gsAppPath & "\" & sAreaID & "\" & sQuestionID & ".png")

        iRandom = Int(Rnd() * 4) + 1
        Select Case iRandom
            Case 1
                picCorrect.Left = 161
                picCorrect.Top = 65
                picWrong1.Left = 327
                picWrong1.Top = 65
                picWrong2.Left = 161
                picWrong2.Top = 170
                picWrong3.Left = 327
                picWrong3.Top = 170
            Case 2
                picWrong3.Left = 161
                picWrong3.Top = 65
                picCorrect.Left = 327
                picCorrect.Top = 65
                picWrong1.Left = 161
                picWrong1.Top = 170
                picWrong2.Left = 327
                picWrong2.Top = 170
            Case 3
                picWrong2.Left = 161
                picWrong2.Top = 65
                picWrong3.Left = 327
                picWrong3.Top = 65
                picCorrect.Left = 161
                picCorrect.Top = 170
                picWrong1.Left = 327
                picWrong1.Top = 170
            Case 4
                picWrong1.Left = 161
                picWrong1.Top = 65
                picWrong2.Left = 327
                picWrong2.Top = 65
                picWrong3.Left = 161
                picWrong3.Top = 170
                picCorrect.Left = 327
                picCorrect.Top = 170
        End Select

        picCorrect.Visible = True
        picWrong1.Visible = True
        picWrong2.Visible = True
        picWrong3.Visible = True

        gdsData.Tables("PractiseQuestions").Reset()

    End Sub

    Private Sub picCorrect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picCorrect.Click

        DisplayResult(True)

    End Sub

    Private Sub picWrong1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picWrong1.Click

        DisplayResult(False)

    End Sub

    Private Sub picWrong2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picWrong2.Click

        DisplayResult(False)

    End Sub

    Private Sub picWrong3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picWrong3.Click

        DisplayResult(False)

    End Sub

    Private Sub DisplayResult(ByVal bCorrect As Boolean)

        Me.Cursor = Cursors.Default

        If bCorrect Then
            lblResult.ForeColor = Color.Green
            lblResult.Text = "Correct"
            miTestScore = miTestScore + 1
        Else
            lblResult.ForeColor = Color.Red
            lblResult.Text = "Incorrect"
        End If

        Application.DoEvents()
        System.Threading.Thread.Sleep(2000)

        lblResult.ForeColor = Color.Black
        lblResult.Text = "Score: " & miTestScore & "/10"
        Application.DoEvents()
        System.Threading.Thread.Sleep(1000)
        'lblResult.Text = ""

        If miQuestionsAsked < NoOfQuestionsInTest Then
            SelectRandomTestQuestion()
        Else
            'MsgBox("test over")
            SaveTestResult()
            msClosingRoute = "TestComplete"
            Me.Close()
        End If

    End Sub

    Private Sub picCorrect_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles picCorrect.MouseEnter

        Me.Cursor = Cursors.Hand

    End Sub


    Private Sub picCorrect_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picCorrect.MouseLeave

        Me.Cursor = Cursors.Default

    End Sub

    Private Sub picWrong1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong1.MouseEnter

        Me.Cursor = Cursors.Hand

    End Sub

    Private Sub picWrong1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong1.MouseLeave

        Me.Cursor = Cursors.Default

    End Sub

    Private Sub picWrong2_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong2.MouseEnter

        Me.Cursor = Cursors.Hand

    End Sub

    Private Sub picWrong2_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong2.MouseLeave

        Me.Cursor = Cursors.Default

    End Sub

    Private Sub picWrong3_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong3.MouseEnter

        Me.Cursor = Cursors.Hand

    End Sub

    Private Sub picWrong3_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong3.MouseLeave

        Me.Cursor = Cursors.Default

    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click

        msClosingRoute = "Back"
        Me.Close()

    End Sub

    Private Sub SaveTestResult()

        Dim sSQL As String
        Dim cmd As OleDb.OleDbCommand 'required locally

        sSQL = "INSERT INTO tblUserResults VALUES("
        sSQL = sSQL & iGetNextID("tblUserresults", "nlUserResultID") & ", "
        sSQL = sSQL & "'" & gsLoggedOnUsername & "', "
        sSQL = sSQL & miTestAreaID & ", "
        sSQL = sSQL & "#" & Format(Now, "dd MMMM yyyy") & "#, " 'error on this line unless I format into UK date!
        sSQL = sSQL & "#" & Now & "#, "
        sSQL = sSQL & miTestScore & ")"
        cmd = New OleDb.OleDbCommand(sSQL, gCon)
        cmd.ExecuteNonQuery()

    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class