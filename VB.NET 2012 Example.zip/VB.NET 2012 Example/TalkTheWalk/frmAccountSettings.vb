﻿Public Class frmAccountSettings

    Public miPasswordChangeStage As Integer = 0
    Public msNewPasswordEntry1 As String = ""

    Private Sub frmAccountSettings_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        frmUser.Show()

    End Sub

    Private Sub frmAccountSettings_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        LoadGenericFormSettings(Me)

        'picLogo.Left = 5
        'picLogo.Top = 5
        'lblTitle.Left = 135
        'lblTitle.Top = 5
        'lblWelcome.Left = 335
        'lblWelcome.Top = 5

        lblWelcome.Text = gsWelcomeText
        lblTitle.Text = "Account Settings"

        SetUpForm()

        txtPassword.Visible = False
        txtPassword.PasswordChar = "*"
        lblPasswordSub.Visible = False
        cmdPasswordOK.Visible = False
        cmdPasswordCancel.Visible = False

    End Sub

    Private Sub SetUpForm()

        lblUsername.Text = gsLoggedOnUsername
        txtFirstName.Text = gsLoggedOnUserFirstName
        txtLastName.Text = gsLoggedOnUserLastName
        txtEmailAddress.Text = gsLoggedOnUserEmail
        cmdSave.Enabled = False
        cmdCancel.Enabled = False

    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        Dim sSQL As String
        Dim cmd As OleDb.OleDbCommand
        Dim sValidationErrorMessage = ""

        If txtFirstName.Text = "" Then
            sValidationErrorMessage = sValidationErrorMessage & "Please enter a First Name" & vbNewLine
        End If
        If txtLastName.Text = "" Then
            sValidationErrorMessage = sValidationErrorMessage & "Please enter a Last Name" & vbNewLine
        End If
        If txtEmailAddress.Text = "" Then 'could be developed further to strictly validate email address
            sValidationErrorMessage = sValidationErrorMessage & "Please enter an EmailAddress" & vbNewLine
        End If

        If sValidationErrorMessage = "" Then
            sSQL = "UPDATE tblUsers SET "
            sSQL = sSQL & "tFirstName = '" & txtFirstName.Text & "', "
            sSQL = sSQL & "tLastName = '" & txtLastName.Text & "', "
            sSQL = sSQL & "tEmailAddress = '" & txtEmailAddress.Text & "' "
            sSQL = sSQL & "WHERE tUsername = '" & gsLoggedOnUsername & "'"
            cmd = New OleDb.OleDbCommand(sSQL, gCon)
            cmd.ExecuteNonQuery()

            MsgBox("Account Settings Updated")
            gsLoggedOnUserFirstName = txtFirstName.Text
            gsLoggedOnUserLastName = txtLastName.Text
            gsLoggedOnUserEmail = txtEmailAddress.Text
            cmdSave.Enabled = False
            LoadWelcome("Standard User")
            lblWelcome.Text = gsWelcomeText
        Else
            MsgBox(sValidationErrorMessage, MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub txtFirstName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFirstName.TextChanged

        cmdSave.Enabled = True
        cmdCancel.Enabled = True

    End Sub

    Private Sub txtLastName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLastName.TextChanged

        cmdSave.Enabled = True
        cmdCancel.Enabled = True

    End Sub

    Private Sub txtEmailAddress_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtEmailAddress.TextChanged

        cmdSave.Enabled = True
        cmdCancel.Enabled = True

    End Sub

    Private Sub SetupPasswordChange()

        txtPassword.Visible = True
        lblPasswordSub.Text = "Enter current:"
        lblPasswordSub.Visible = True
        cmdPasswordChange.Visible = False
        cmdSave.Visible = False
        cmdCancel.Visible = False
        cmdPasswordOK.Visible = True
        cmdPasswordOK.Enabled = False
        cmdPasswordCancel.Visible = True
        txtPassword.Focus()

    End Sub

    Private Sub txtPassword_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPassword.TextChanged

        cmdPasswordOK.Enabled = True
        cmdPasswordCancel.Enabled = True

    End Sub

    Private Sub cmdPasswordOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPasswordOK.Click

        ChangePassword()

    End Sub

    Private Sub ChangePassword()

        Select Case miPasswordChangeStage
            Case 0
                If txtPassword.Text = gsLoggedOnUserPassword Then
                    lblPasswordSub.Text = "Enter new:"
                    txtPassword.Text = ""
                    cmdPasswordOK.Enabled = False
                    miPasswordChangeStage = 1
                    txtPassword.Focus()
                Else
                    MsgBox("Password entered doesn't match current password. Please try again.", MsgBoxStyle.Exclamation)
                    txtPassword.Text = ""
                    cmdPasswordOK.Enabled = False
                    txtPassword.Focus()
                End If
            Case 1
                msNewPasswordEntry1 = txtPassword.Text
                lblPasswordSub.Text = "Confirm new:"
                txtPassword.Text = ""
                cmdPasswordOK.Enabled = False
                miPasswordChangeStage = 2
                txtPassword.Focus()
            Case 2
                If txtPassword.Text = msNewPasswordEntry1 Then
                    WriteNewPasswordToDatabase()
                    gsLoggedOnUserPassword = txtPassword.Text
                    MsgBox("Password successfully changed.", MsgBoxStyle.Information)
                    SetUpPasswordForm()
                Else
                    MsgBox("New password entries don't match. Please try again")
                    lblPasswordSub.Text = "Enter new:"
                    msNewPasswordEntry1 = ""
                    cmdPasswordOK.Enabled = False
                    miPasswordChangeStage = 1
                    txtPassword.Text = ""
                End If
        End Select

    End Sub

    Private Sub cmdPasswordCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPasswordCancel.Click

        SetUpPasswordForm()

    End Sub

    Private Sub SetUpPasswordForm()

        miPasswordChangeStage = 0
        lblPasswordSub.Text = "Enter current:"
        cmdPasswordOK.Visible = False
        cmdPasswordCancel.Visible = False
        txtPassword.Visible = False
        txtPassword.Text = ""
        lblPasswordSub.Visible = False
        cmdSave.Visible = True
        cmdCancel.Visible = True
        cmdPasswordChange.Visible = True

    End Sub

    Private Sub WriteNewPasswordToDatabase()

        Dim sSQL As String
        Dim cmd As OleDb.OleDbCommand

        sSQL = "UPDATE tblUsers "
        sSQL = sSQL & "SET tUserPassword = '" & txtPassword.Text & "' "
        sSQL = sSQL & "WHERE tUsername = '" & gsLoggedOnUsername & "'"
        cmd = New OleDb.OleDbCommand(sSQL, gCon)
        cmd.ExecuteNonQuery()

    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click

        SetUpForm()

    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click

        SetUpForm()
        SetUpPasswordForm()
        frmUser.Show()
        Me.Hide()

    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class