﻿Public Class frmAdminChoice

    Private Sub frmAdminChoice_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        LoadGenericFormSettings(Me)

        'picLogo.Left = 10
        'picLogo.Top = 10
        'lblTitle.Left = 135
        'lblTitle.Top = 10
        'lblWelcome.Left = 335
        'lblWelcome.Top = 10

        lblWelcome.Text = gsWelcomeText
        lblTitle.Text = "Choose User Mode"

    End Sub

    Private Sub cmdAdmin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdminChoice.Click

        frmAdmin.Show()
        Me.Hide()

    End Sub

    Private Sub cmdUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUser.Click

        frmUser.Show()
        Me.Hide()

    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class