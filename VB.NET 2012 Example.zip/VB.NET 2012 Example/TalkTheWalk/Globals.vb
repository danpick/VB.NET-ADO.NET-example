﻿Module Globals

    Public gsAppPath As String = Application.StartupPath

    Public gCon As New OleDb.OleDbConnection
    Public gdsData As New DataSet
    Public gda As OleDb.OleDbDataAdapter

    Public gsLoggedOnUsername As String
    Public gsLoggedOnUserPassword As String
    Public gsLoggedOnUserFirstName As String
    Public gsLoggedOnUserLastName As String
    Public gsLoggedOnUserEmail As String
    Public gbLoggedOnUserAdmin As Boolean

    Public gsWelcomeText As String

    Public gsResultsHTML As String

    Public Sub LoadGenericFormSettings(ByVal oForm As Form)

        oForm.Text = "TalkTheWalk v" & Application.ProductVersion
        oForm.Height = 320
        oForm.Width = 520
        oForm.Left = 0
        oForm.Top = 0
        oForm.BackColor = Color.White

    End Sub

    Public Sub LoadWelcome(ByVal sUserType As String)

        gsWelcomeText = "Welcome " & gsLoggedOnUsername & vbNewLine
        gsWelcomeText = gsWelcomeText & gsLoggedOnUserFirstName & " " & gsLoggedOnUserLastName & vbNewLine
        gsWelcomeText = gsWelcomeText & gsLoggedOnUserEmail & vbNewLine
        gsWelcomeText = gsWelcomeText & sUserType & vbNewLine

    End Sub

    Public Function iGetNextID(ByVal sTableName As String, ByVal sPKName As String)

        Dim sSQL As String

        sSQL = "SELECT MAX(" & sPKName & ") AS MaxID "
        sSQL = sSQL & "FROM " & sTableName
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "MaxIDTable")

        If Str(gdsData.Tables("MaxIDTable").Rows(0).Item("MaxID")) = "Null" Then 'error without this line
            iGetNextID = 1
        Else
            iGetNextID = gdsData.Tables("MaxIDTable").Rows(0).Item("MaxID") + 1
        End If


    End Function

    Public Sub gPopulateAreasCombo(ByVal oForm As Windows.Forms.Form)

        Dim sSQL As String
        Dim iAreaID As Integer
        Dim sAreaName As String

        sSQL = "SELECT niAreaID, tAreaName FROM tblAreas ORDER BY tAreaName ASC"
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "Areas")

        For i = 0 To gdsData.Tables("Areas").Rows.Count - 1
            iAreaID = gdsData.Tables("Areas").Rows(i).Item("niAreaID")
            sAreaName = gdsData.Tables("Areas").Rows(i).Item("tAreaName")
            Select Case oForm.Name
                Case "frmReference"
                    frmReference.cboAreas.Items.Add(New ValueDescriptionPair(iAreaID, sAreaName))
                Case "frmPractise"
                    frmPractise.cboAreas.Items.Add(New ValueDescriptionPair(iAreaID, sAreaName))
                Case "frmTest"
                    frmTest.cboAreas.Items.Add(New ValueDescriptionPair(iAreaID, sAreaName))
            End Select
        Next i

        gdsData.Tables("Areas").Reset()

    End Sub

    Public Sub gPrintResults(ByVal sMode As String)

        Dim sFileName As String

        sFileName = Application.StartupPath & "\" & sMode & "Results\" & gsLoggedOnUsername & " " & Format(Now, "yyyyMMdd hhmmss") & ".html"

        Dim objWriter As New System.IO.StreamWriter(sFileName)
        objWriter.WriteLine("<html>")
        objWriter.WriteLine("</head>")
        objWriter.WriteLine("<style type=""text/css""> h1,h2,h3{font-family:Arial, Serif;}  table{border-collapse:collapse; width:75%; font-family:Arial,Helvetica,Sans-serif;} th{height:30px;} td{text-align:left; padding:7px;} table, th, td{border:1px solid green;} </style>")
        objWriter.WriteLine("</head>")
        objWriter.WriteLine("<body>")
        objWriter.WriteLine("<p align=center>")
        objWriter.WriteLine("<img src='..\TalkTheWalkLogo.png'>")
        objWriter.WriteLine("<h1 align=center>")
        objWriter.WriteLine("Hills and Moorland Leader Awards")
        objWriter.WriteLine("</h1>")
        objWriter.WriteLine("<h2 align=center>")
        objWriter.WriteLine("Test Results")
        objWriter.WriteLine("</h2>")
        objWriter.WriteLine("<h3 align=center>")
        objWriter.WriteLine("Username: " & gsLoggedOnUsername & "<br>")
        objWriter.WriteLine("Last Name: " & gsLoggedOnUserLastName & "<br>")
        objWriter.WriteLine("First Name: " & gsLoggedOnUserFirstName & "<br>")
        objWriter.WriteLine("Email: " & gsLoggedOnUserEmail)
        objWriter.WriteLine("</h3>")
        objWriter.WriteLine("<table align=center>")
        objWriter.WriteLine("<tr>")
        If sMode = "Admin" Then
            objWriter.WriteLine("<td width=25%><b>User ID</b>")
            objWriter.WriteLine("</td>")
        End If
        objWriter.WriteLine("<td width=25%><b>Date/Time</b>")
        objWriter.WriteLine("</td>")
        objWriter.WriteLine("<td width=25%><b>Area</b>")
        objWriter.WriteLine("</td>")
        objWriter.WriteLine("<td width=25%><b>Score</b>")
        objWriter.WriteLine("</td>")
        objWriter.WriteLine("</tr>")
        objWriter.WriteLine(gsResultsHTML)
        objWriter.WriteLine("</table>")
        objWriter.WriteLine("</p>")
        objWriter.WriteLine("</body>")
        objWriter.WriteLine("</html>")
        objWriter.Close()

        Process.Start(sFileName)

    End Sub

    Public Sub gDisplayHelpMessage()

        Dim sMsg As String

        sMsg = "Please see you system administrator for help with any issues" & vbNewLine & vbNewLine
        sMsg = sMsg & "email: sysadmin@talkthewalk.co.uk, tel: 01542 444 4244"
        MsgBox(sMsg, MsgBoxStyle.Information)

    End Sub

End Module

