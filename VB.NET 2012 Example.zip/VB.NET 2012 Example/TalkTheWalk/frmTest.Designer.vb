﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTest))
        Me.lblWelcome = New System.Windows.Forms.Label
        Me.lblTitle = New System.Windows.Forms.Label
        Me.picLogo = New System.Windows.Forms.PictureBox
        Me.cboAreas = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.lblQuestion = New System.Windows.Forms.Label
        Me.picCorrect = New System.Windows.Forms.PictureBox
        Me.picWrong1 = New System.Windows.Forms.PictureBox
        Me.picWrong2 = New System.Windows.Forms.PictureBox
        Me.picWrong3 = New System.Windows.Forms.PictureBox
        Me.lblResult = New System.Windows.Forms.Label
        Me.cmdBack = New System.Windows.Forms.Button
        Me.cmdHelp = New System.Windows.Forms.Button
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCorrect, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWrong1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWrong2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWrong3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblWelcome
        '
        Me.lblWelcome.Location = New System.Drawing.Point(331, 5)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(150, 115)
        Me.lblWelcome.TabIndex = 11
        Me.lblWelcome.Text = "Welcome"
        Me.lblWelcome.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblTitle
        '
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(55, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(285, 28)
        Me.lblTitle.TabIndex = 10
        Me.lblTitle.Text = "Label1"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picLogo
        '
        Me.picLogo.Image = CType(resources.GetObject("picLogo.Image"), System.Drawing.Image)
        Me.picLogo.Location = New System.Drawing.Point(3, 6)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(46, 47)
        Me.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLogo.TabIndex = 12
        Me.picLogo.TabStop = False
        '
        'cboAreas
        '
        Me.cboAreas.FormattingEnabled = True
        Me.cboAreas.Location = New System.Drawing.Point(3, 83)
        Me.cboAreas.Name = "cboAreas"
        Me.cboAreas.Size = New System.Drawing.Size(129, 21)
        Me.cboAreas.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Please select an area:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 123)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Identify:"
        '
        'lblQuestion
        '
        Me.lblQuestion.AutoSize = True
        Me.lblQuestion.Location = New System.Drawing.Point(6, 152)
        Me.lblQuestion.Name = "lblQuestion"
        Me.lblQuestion.Size = New System.Drawing.Size(50, 13)
        Me.lblQuestion.TabIndex = 16
        Me.lblQuestion.Text = "mountain"
        '
        'picCorrect
        '
        Me.picCorrect.Location = New System.Drawing.Point(161, 65)
        Me.picCorrect.Name = "picCorrect"
        Me.picCorrect.Size = New System.Drawing.Size(160, 100)
        Me.picCorrect.TabIndex = 17
        Me.picCorrect.TabStop = False
        '
        'picWrong1
        '
        Me.picWrong1.Location = New System.Drawing.Point(327, 65)
        Me.picWrong1.Name = "picWrong1"
        Me.picWrong1.Size = New System.Drawing.Size(160, 100)
        Me.picWrong1.TabIndex = 18
        Me.picWrong1.TabStop = False
        '
        'picWrong2
        '
        Me.picWrong2.Location = New System.Drawing.Point(161, 170)
        Me.picWrong2.Name = "picWrong2"
        Me.picWrong2.Size = New System.Drawing.Size(160, 100)
        Me.picWrong2.TabIndex = 19
        Me.picWrong2.TabStop = False
        '
        'picWrong3
        '
        Me.picWrong3.Location = New System.Drawing.Point(327, 170)
        Me.picWrong3.Name = "picWrong3"
        Me.picWrong3.Size = New System.Drawing.Size(160, 100)
        Me.picWrong3.TabIndex = 20
        Me.picWrong3.TabStop = False
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(4, 172)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(79, 25)
        Me.lblResult.TabIndex = 21
        Me.lblResult.Text = "Result"
        '
        'cmdBack
        '
        Me.cmdBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBack.Location = New System.Drawing.Point(9, 223)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.Size = New System.Drawing.Size(46, 40)
        Me.cmdBack.TabIndex = 29
        Me.cmdBack.Text = "<"
        Me.cmdBack.UseVisualStyleBackColor = True
        '
        'cmdHelp
        '
        Me.cmdHelp.Location = New System.Drawing.Point(9, 200)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.Size = New System.Drawing.Size(42, 20)
        Me.cmdHelp.TabIndex = 30
        Me.cmdHelp.Text = "Help"
        Me.cmdHelp.UseVisualStyleBackColor = True
        '
        'frmTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 273)
        Me.Controls.Add(Me.cmdHelp)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.picWrong3)
        Me.Controls.Add(Me.picWrong2)
        Me.Controls.Add(Me.picWrong1)
        Me.Controls.Add(Me.picCorrect)
        Me.Controls.Add(Me.lblQuestion)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboAreas)
        Me.Controls.Add(Me.picLogo)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.lblTitle)
        Me.Name = "frmTest"
        Me.Text = "frm"
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCorrect, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWrong1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWrong2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWrong3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblWelcome As System.Windows.Forms.Label
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents picLogo As System.Windows.Forms.PictureBox
    Friend WithEvents cboAreas As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblQuestion As System.Windows.Forms.Label
    Friend WithEvents picCorrect As System.Windows.Forms.PictureBox
    Friend WithEvents picWrong1 As System.Windows.Forms.PictureBox
    Friend WithEvents picWrong2 As System.Windows.Forms.PictureBox
    Friend WithEvents picWrong3 As System.Windows.Forms.PictureBox
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents cmdBack As System.Windows.Forms.Button
    Friend WithEvents cmdHelp As System.Windows.Forms.Button
End Class
