﻿Public Class frmUser

    Private Sub frmUser_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        End
    End Sub

    Private Sub frmUser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        LoadGenericFormSettings(Me)

        'picLogo.Left = 10
        'picLogo.Top = 10
        'lblTitle.Left = 135
        'lblTitle.Top = 10
        'lblWelcome.Left = 335
        'lblWelcome.Top = 10

        lblWelcome.Text = gsWelcomeText
        lblTitle.Text = "Standard User"

    End Sub

    Private Sub cmdAccountSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAccountSettings.Click

        frmAccountSettings.Show()
        Me.Hide()

    End Sub

    Private Sub cmdPractise_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPractise.Click

        frmPractise.Show()
        Me.Hide()

    End Sub

    Private Sub cmdTakeTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdTakeTest.Click

        frmTest.Show()
        Me.Hide()

    End Sub

    Private Sub cmdTestResults_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdTestResults.Click

        frmUserResults.Show()
        Me.Hide()

    End Sub

    Private Sub cmdRef_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRef.Click

        frmReference.Show()
        Me.Hide()

    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class