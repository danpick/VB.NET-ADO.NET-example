﻿Public Class frmPractise

    Dim msQuestionID As String

    Private Sub frmPractise_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        frmUser.Show()

    End Sub

    Private Sub frmPractise_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        LoadGenericFormSettings(Me)

        'picLogo.Left = 10
        'picLogo.Top = 5
        'lblTitle.Left = 135
        'lblTitle.Top = 5
        'lblWelcome.Left = 335
        'lblWelcome.Top = 5

        lblWelcome.Text = gsWelcomeText
        lblTitle.Text = "Practise Test"
        cboAreas.DropDownStyle = ComboBoxStyle.DropDownList
        picCorrect.SizeMode = PictureBoxSizeMode.StretchImage
        picWrong1.SizeMode = PictureBoxSizeMode.StretchImage
        picWrong2.SizeMode = PictureBoxSizeMode.StretchImage
        picWrong3.SizeMode = PictureBoxSizeMode.StretchImage
        picCorrect.Visible = False
        picWrong1.Visible = False
        picWrong2.Visible = False
        picWrong3.Visible = False
        lblQuestion.Text = ""
        lblResult.Text = ""

        gPopulateAreasCombo(Me)

    End Sub

    Private Sub cmdAccountSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        frmAccountSettings.Show()
        Me.Hide()

    End Sub

    'Private Sub PopulateAreasCombo()

    '    Dim sSQL As String
    '    Dim iAreaID As Integer
    '    Dim sAreaName As String

    '    'cboAreas.ResetText()
    '    'cboAreas.Items.Clear()

    '    sSQL = "SELECT niAreaID, tAreaName FROM tblAreas ORDER BY tAreaName ASC"
    '    gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
    '    gda.Fill(gdsData, "Areas")

    '    For i = 0 To gdsData.Tables("Areas").Rows.Count - 1
    '        iAreaID = gdsData.Tables("Areas").Rows(i).Item("niAreaID")
    '        sAreaName = gdsData.Tables("Areas").Rows(i).Item("tAreaName")
    '        cboAreas.Items.Add(New ValueDescriptionPair(iAreaID, sAreaName))
    '    Next i

    'End Sub

    Private Sub cboAreas_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboAreas.SelectedIndexChanged

        ResetPractiseQuestions()
        SelectRandomPractiseQuestion()

    End Sub

    Private Sub SelectRandomPractiseQuestion()

        Dim sSQL As String
        Dim iItemSelected As Integer = CType(cboAreas.SelectedItem, ValueDescriptionPair).Value
        Dim sAreaID As String = Format(iItemSelected, "000")
        Dim iRandom As Integer = 0
        Dim sWrongID As String

        sSQL = "SELECT niQuestionID, "
        sSQL = sSQL & "tQuestionText "
        sSQL = sSQL & "FROM tblQuestions "
        sSQL = sSQL & "WHERE niAreaID = " & iItemSelected & " " 'will error if no database entries/images for selected area
        sSQL = sSQL & "AND bCorrectInPractise = No "
        sSQL = sSQL & "ORDER BY Rnd([niQuestionID])"
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "PractiseQuestions")

        'will error on this line if practise complete (all questions correct during practise)
        msQuestionID = Format(gdsData.Tables("PractiseQuestions").Rows(0).Item("niQuestionID"), "000")

        lblQuestion.Text = gdsData.Tables("PractiseQuestions").Rows(0).Item("tQuestionText")
        picCorrect.Image = Image.FromFile(gsAppPath & "\" & sAreaID & "\" & msQuestionID & ".png")

        sSQL = "SELECT niQuestionID, "
        sSQL = sSQL & "tQuestionText "
        sSQL = sSQL & "FROM tblQuestions "
        sSQL = sSQL & "WHERE niAreaID = " & iItemSelected & " "
        sSQL = sSQL & "AND niQuestionID <> " & Int(msQuestionID) & " "
        sSQL = sSQL & "ORDER BY Rnd([niQuestionID])"
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "PractiseWrongs")

        'could be looped using control array
        sWrongID = Format(gdsData.Tables("PractiseWrongs").Rows(0).Item("niQuestionID"), "000")
        picWrong1.Image = Image.FromFile(gsAppPath & "\" & sAreaID & "\" & sWrongID & ".png")

        sWrongID = Format(gdsData.Tables("PractiseWrongs").Rows(1).Item("niQuestionID"), "000")
        picWrong2.Image = Image.FromFile(gsAppPath & "\" & sAreaID & "\" & sWrongID & ".png")

        sWrongID = Format(gdsData.Tables("PractiseWrongs").Rows(3).Item("niQuestionID"), "000")
        picWrong3.Image = Image.FromFile(gsAppPath & "\" & sAreaID & "\" & sWrongID & ".png")

        iRandom = Int(Rnd() * 4) + 1
        Select Case iRandom
            Case 1
                picCorrect.Left = 161
                picCorrect.Top = 65
                picWrong1.Left = 327
                picWrong1.Top = 65
                picWrong2.Left = 161
                picWrong2.Top = 170
                picWrong3.Left = 327
                picWrong3.Top = 170
            Case 2
                picWrong3.Left = 161
                picWrong3.Top = 65
                picCorrect.Left = 327
                picCorrect.Top = 65
                picWrong1.Left = 161
                picWrong1.Top = 170
                picWrong2.Left = 327
                picWrong2.Top = 170
            Case 3
                picWrong2.Left = 161
                picWrong2.Top = 65
                picWrong3.Left = 327
                picWrong3.Top = 65
                picCorrect.Left = 161
                picCorrect.Top = 170
                picWrong1.Left = 327
                picWrong1.Top = 170
            Case 4
                picWrong1.Left = 161
                picWrong1.Top = 65
                picWrong2.Left = 327
                picWrong2.Top = 65
                picWrong3.Left = 161
                picWrong3.Top = 170
                picCorrect.Left = 327
                picCorrect.Top = 170
        End Select

        picCorrect.Visible = True
        picWrong1.Visible = True
        picWrong2.Visible = True
        picWrong3.Visible = True

        gdsData.Tables("PractiseQuestions").Reset()
        'duplicate images displayed without next line
        gdsData.Tables("PractiseWrongs").Reset()
    End Sub

    Private Sub picCorrect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picCorrect.Click

        DisplayCorrect()

    End Sub

    Private Sub picWrong1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picWrong1.Click

        DisplayResult(False)

    End Sub

    Private Sub picWrong2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picWrong2.Click

        DisplayResult(False)

    End Sub

    Private Sub picWrong3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picWrong3.Click

        DisplayResult(False)

    End Sub

    Private Sub DisplayResult(ByVal bCorrect As Boolean)

        Me.Cursor = Cursors.Default

        If bCorrect Then
            lblResult.ForeColor = Color.Green
            lblResult.Text = "Correct"
        Else
            lblResult.ForeColor = Color.Red
            lblResult.Text = "Incorrect"
        End If
        Application.DoEvents()
        System.Threading.Thread.Sleep(2000)

        lblResult.ForeColor = Color.Black
        lblResult.Text = "Try another"
        Application.DoEvents()
        System.Threading.Thread.Sleep(1000)
        lblResult.Text = ""

        SelectRandomPractiseQuestion()

    End Sub

    Private Sub picCorrect_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles picCorrect.MouseEnter


        Me.Cursor = Cursors.Hand

    End Sub


    Private Sub picCorrect_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picCorrect.MouseLeave

        Me.Cursor = Cursors.Default
    End Sub

    Private Sub picWrong1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong1.MouseEnter
        Me.Cursor = Cursors.Hand

    End Sub

    Private Sub picWrong1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong1.MouseLeave
        Me.Cursor = Cursors.Default

    End Sub

    Private Sub picWrong2_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong2.MouseEnter
        Me.Cursor = Cursors.Hand

    End Sub

    Private Sub picWrong2_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong2.MouseLeave
        Me.Cursor = Cursors.Default

    End Sub

    Private Sub picWrong3_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong3.MouseEnter
        Me.Cursor = Cursors.Hand

    End Sub

    Private Sub picWrong3_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picWrong3.MouseLeave
        Me.Cursor = Cursors.Default

    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click

        Me.Close()
    End Sub

    Private Sub ResetPractiseQuestions()

        Dim sSql As String
        Dim cmd As OleDb.OleDbCommand 'required locally

        'new practise session
        sSql = "UPDATE tblQuestions SET bCorrectInPractise = No"
        cmd = New OleDb.OleDbCommand(sSql, gCon)
        cmd.ExecuteNonQuery()

    End Sub

    Private Sub DisplayCorrect()

        Dim sSQL As String
        Dim cmd As OleDb.OleDbCommand 'required locally

        sSQL = "UPDATE tblQuestions SET bCorrectInPractise = Yes WHERE niQuestionID =" & Int(msQuestionID)
        cmd = New OleDb.OleDbCommand(sSQL, gCon)
        cmd.ExecuteNonQuery()

        DisplayResult(True)

    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class