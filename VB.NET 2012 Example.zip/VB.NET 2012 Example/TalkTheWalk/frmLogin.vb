﻿Public Class frmLogin

    Private Sub frmLogin_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        End ' if the login form closes fully within memory, then so should the whole program
    End Sub

    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        DeleteTempImageFiles()
        ConnectToDatabase()
        LoadGenericFormSettings(Me)

        'development
        'txtUsername.Text = "dan77"
        'txtPassword.Text = "bigdog"
        'txtUsername.Text = "dickyt"
        'txtPassword.Text = "grassington"

        txtUsername.Focus() 'usability feature for ease of use
        txtPassword.PasswordChar = "*" 'masks password field
        Me.AcceptButton = cmdLogin 'default button for form - equivalent of clicking Login button

    End Sub

    Private Sub cmdLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLogin.Click

        Login()

    End Sub

    Private Sub ConnectToDatabase()

        'utilises ADO.NET and in particular Mirosoft ACE engine to connect with MS Access Database

        Dim msProvider As String
        Dim msSource As String

        msProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"
        msSource = "Data Source = " & gsAppPath & "\TalkTheWalk.mdb"

        gCon.ConnectionString = msProvider & msSource
        gCon.Open()

    End Sub

    Private Sub Login()

        Dim sSQL As String

        'query to select any records in users table that match username entered by user
        sSQL = "SELECT tUserName, "
        sSQL = sSQL & "tUserPassword, "
        sSQL = sSQL & "tFirstName, "
        sSQL = sSQL & "tLastName, "
        sSQL = sSQL & "tEmailAddress, "
        sSQL = sSQL & "bAdminUser "
        sSQL = sSQL & "FROM tblUsers "
        sSQL = sSQL & "WHERE tUserName = '" & txtUsername.Text & "'"
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "UserAuthentication") 'stores any results in data table "UserAuthentication"

        If gdsData.Tables("UserAuthentication").Rows.Count = 0 Then 'no matching user found

            MsgBox("The username entered does not exist. Please re-try or see your administrator", MsgBoxStyle.Exclamation, "Talk The Walk")
            txtUsername.Focus()
        Else 'matching user found
            gsLoggedOnUserPassword = gdsData.Tables("UserAuthentication").Rows(0).Item("tUserPassword") 'retrieve correct password
            If txtPassword.Text <> gsLoggedOnUserPassword Then 'check password entered against correct password - if they don't match...
                MsgBox("The password entered does not match the username entered. Please try again or see your administrator", MsgBoxStyle.Exclamation, "Talk The Walk")
                txtPassword.Text = ""
                txtPassword.Focus()
            Else 'if they do match
                gsLoggedOnUsername = gdsData.Tables("UserAuthentication").Rows(0).Item("tUserName")
                gsLoggedOnUserFirstName = gdsData.Tables("UserAuthentication").Rows(0).Item("tFirstName")
                gsLoggedOnUserLastName = gdsData.Tables("UserAuthentication").Rows(0).Item("tLastName")
                gsLoggedOnUserEmail = gdsData.Tables("UserAuthentication").Rows(0).Item("tEmailAddress")

                gbLoggedOnUserAdmin = gdsData.Tables("UserAuthentication").Rows(0).Item("bAdminUser")
                If gbLoggedOnUserAdmin = True Then 'if an admin level user
                    LoadWelcome("Admin User/Standard User")
                    frmAdminChoice.Show()
                Else 'if a standard user
                    LoadWelcome("Standard User")
                    frmUser.Show()
                End If

                Me.Hide() 'if user is logged on, hide login form, but do not close from memory

            End If
        End If

    End Sub

    Private Sub DeleteTempImageFiles()

        'deletes any temporary files that are created as a result of an admin user updating/re-loading images for questions

        For Each foundFile As String In My.Computer.FileSystem.GetFiles(Application.StartupPath, Microsoft.VisualBasic.FileIO.SearchOption.SearchAllSubDirectories, "*.OLD")
            My.Computer.FileSystem.DeleteFile(foundFile)
        Next
        For Each foundFile As String In My.Computer.FileSystem.GetFiles(Application.StartupPath, Microsoft.VisualBasic.FileIO.SearchOption.SearchAllSubDirectories, "*.COPY")
            My.Computer.FileSystem.DeleteFile(foundFile)
        Next

    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class