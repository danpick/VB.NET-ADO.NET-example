﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReference
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReference))
        Me.lblWelcome = New System.Windows.Forms.Label
        Me.lblTitle = New System.Windows.Forms.Label
        Me.cmdBack = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.cboAreas = New System.Windows.Forms.ComboBox
        Me.picLogo = New System.Windows.Forms.PictureBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtRefSearch = New System.Windows.Forms.TextBox
        Me.lstRefResults = New System.Windows.Forms.ListBox
        Me.picRef = New System.Windows.Forms.PictureBox
        Me.cmdHelp = New System.Windows.Forms.Button
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRef, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblWelcome
        '
        Me.lblWelcome.Location = New System.Drawing.Point(331, 12)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(150, 115)
        Me.lblWelcome.TabIndex = 11
        Me.lblWelcome.Text = "Welcome"
        Me.lblWelcome.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblTitle
        '
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(132, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(193, 64)
        Me.lblTitle.TabIndex = 10
        Me.lblTitle.Text = "Label1"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdBack
        '
        Me.cmdBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBack.Location = New System.Drawing.Point(12, 214)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.Size = New System.Drawing.Size(55, 47)
        Me.cmdBack.TabIndex = 15
        Me.cmdBack.Text = "<"
        Me.cmdBack.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 13)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Please select an area:"
        '
        'cboAreas
        '
        Me.cboAreas.FormattingEnabled = True
        Me.cboAreas.Location = New System.Drawing.Point(12, 87)
        Me.cboAreas.Name = "cboAreas"
        Me.cboAreas.Size = New System.Drawing.Size(129, 21)
        Me.cboAreas.TabIndex = 16
        '
        'picLogo
        '
        Me.picLogo.Image = CType(resources.GetObject("picLogo.Image"), System.Drawing.Image)
        Me.picLogo.Location = New System.Drawing.Point(12, 9)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(46, 47)
        Me.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLogo.TabIndex = 18
        Me.picLogo.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(169, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 13)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Search for a hill/mountain:"
        '
        'txtRefSearch
        '
        Me.txtRefSearch.Location = New System.Drawing.Point(169, 88)
        Me.txtRefSearch.Name = "txtRefSearch"
        Me.txtRefSearch.Size = New System.Drawing.Size(120, 20)
        Me.txtRefSearch.TabIndex = 20
        '
        'lstRefResults
        '
        Me.lstRefResults.FormattingEnabled = True
        Me.lstRefResults.Location = New System.Drawing.Point(86, 120)
        Me.lstRefResults.Name = "lstRefResults"
        Me.lstRefResults.Size = New System.Drawing.Size(203, 134)
        Me.lstRefResults.TabIndex = 21
        '
        'picRef
        '
        Me.picRef.Location = New System.Drawing.Point(309, 120)
        Me.picRef.Name = "picRef"
        Me.picRef.Size = New System.Drawing.Size(160, 100)
        Me.picRef.TabIndex = 22
        Me.picRef.TabStop = False
        '
        'cmdHelp
        '
        Me.cmdHelp.Location = New System.Drawing.Point(12, 188)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.Size = New System.Drawing.Size(42, 20)
        Me.cmdHelp.TabIndex = 30
        Me.cmdHelp.Text = "Help"
        Me.cmdHelp.UseVisualStyleBackColor = True
        '
        'frmReference
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 273)
        Me.Controls.Add(Me.cmdHelp)
        Me.Controls.Add(Me.picRef)
        Me.Controls.Add(Me.lstRefResults)
        Me.Controls.Add(Me.txtRefSearch)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.picLogo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboAreas)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.lblTitle)
        Me.Name = "frmReference"
        Me.Text = "frm"
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRef, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblWelcome As System.Windows.Forms.Label
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents cmdBack As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboAreas As System.Windows.Forms.ComboBox
    Friend WithEvents picLogo As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtRefSearch As System.Windows.Forms.TextBox
    Friend WithEvents lstRefResults As System.Windows.Forms.ListBox
    Friend WithEvents picRef As System.Windows.Forms.PictureBox
    Friend WithEvents cmdHelp As System.Windows.Forms.Button
End Class
