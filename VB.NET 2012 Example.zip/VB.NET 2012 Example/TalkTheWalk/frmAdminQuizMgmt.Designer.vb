﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminQuizMgmt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAdminQuizMgmt))
        Me.picLogo = New System.Windows.Forms.PictureBox
        Me.lblTitle = New System.Windows.Forms.Label
        Me.lblWelcome = New System.Windows.Forms.Label
        Me.pnlQuizSelection = New System.Windows.Forms.Panel
        Me.cmdSaveNewQuiz = New System.Windows.Forms.Button
        Me.lblEnterNewQuizName = New System.Windows.Forms.Label
        Me.txtNewQuizName = New System.Windows.Forms.TextBox
        Me.cmdAddNewQuiz = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.lstQuizzes = New System.Windows.Forms.ListBox
        Me.pnlEditQuiz = New System.Windows.Forms.Panel
        Me.cmdSaveChanges = New System.Windows.Forms.Button
        Me.picQuestionImage = New System.Windows.Forms.PictureBox
        Me.cmdAddNewQuestion = New System.Windows.Forms.Button
        Me.lblChangeQuestionImage = New System.Windows.Forms.Label
        Me.txtChangeQuestionText = New System.Windows.Forms.TextBox
        Me.lblChangeQuestionText = New System.Windows.Forms.Label
        Me.cmdDeleteQuestion = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.lstQuestions = New System.Windows.Forms.ListBox
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.cmdBack = New System.Windows.Forms.Button
        Me.cmdHelp = New System.Windows.Forms.Button
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlQuizSelection.SuspendLayout()
        Me.pnlEditQuiz.SuspendLayout()
        CType(Me.picQuestionImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picLogo
        '
        Me.picLogo.Image = CType(resources.GetObject("picLogo.Image"), System.Drawing.Image)
        Me.picLogo.Location = New System.Drawing.Point(10, 10)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(40, 40)
        Me.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLogo.TabIndex = 4
        Me.picLogo.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(136, -14)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(193, 64)
        Me.lblTitle.TabIndex = 5
        Me.lblTitle.Text = "Label1"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblWelcome
        '
        Me.lblWelcome.Location = New System.Drawing.Point(335, 10)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(150, 115)
        Me.lblWelcome.TabIndex = 8
        Me.lblWelcome.Text = "Welcome"
        Me.lblWelcome.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'pnlQuizSelection
        '
        Me.pnlQuizSelection.Controls.Add(Me.cmdSaveNewQuiz)
        Me.pnlQuizSelection.Controls.Add(Me.lblEnterNewQuizName)
        Me.pnlQuizSelection.Controls.Add(Me.txtNewQuizName)
        Me.pnlQuizSelection.Controls.Add(Me.cmdAddNewQuiz)
        Me.pnlQuizSelection.Controls.Add(Me.Label1)
        Me.pnlQuizSelection.Controls.Add(Me.lstQuizzes)
        Me.pnlQuizSelection.Location = New System.Drawing.Point(10, 84)
        Me.pnlQuizSelection.Name = "pnlQuizSelection"
        Me.pnlQuizSelection.Size = New System.Drawing.Size(474, 159)
        Me.pnlQuizSelection.TabIndex = 12
        '
        'cmdSaveNewQuiz
        '
        Me.cmdSaveNewQuiz.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSaveNewQuiz.Location = New System.Drawing.Point(297, 128)
        Me.cmdSaveNewQuiz.Name = "cmdSaveNewQuiz"
        Me.cmdSaveNewQuiz.Size = New System.Drawing.Size(115, 22)
        Me.cmdSaveNewQuiz.TabIndex = 17
        Me.cmdSaveNewQuiz.Text = "Save New Quiz"
        Me.cmdSaveNewQuiz.UseVisualStyleBackColor = True
        '
        'lblEnterNewQuizName
        '
        Me.lblEnterNewQuizName.AutoSize = True
        Me.lblEnterNewQuizName.Location = New System.Drawing.Point(305, 86)
        Me.lblEnterNewQuizName.Name = "lblEnterNewQuizName"
        Me.lblEnterNewQuizName.Size = New System.Drawing.Size(106, 13)
        Me.lblEnterNewQuizName.TabIndex = 16
        Me.lblEnterNewQuizName.Text = "Enter new quiz name"
        '
        'txtNewQuizName
        '
        Me.txtNewQuizName.Location = New System.Drawing.Point(278, 102)
        Me.txtNewQuizName.Name = "txtNewQuizName"
        Me.txtNewQuizName.Size = New System.Drawing.Size(156, 20)
        Me.txtNewQuizName.TabIndex = 15
        '
        'cmdAddNewQuiz
        '
        Me.cmdAddNewQuiz.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddNewQuiz.Location = New System.Drawing.Point(297, 33)
        Me.cmdAddNewQuiz.Name = "cmdAddNewQuiz"
        Me.cmdAddNewQuiz.Size = New System.Drawing.Size(115, 46)
        Me.cmdAddNewQuiz.TabIndex = 14
        Me.cmdAddNewQuiz.Text = "Add New Quiz"
        Me.cmdAddNewQuiz.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(121, 13)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Select a quiz to edit"
        '
        'lstQuizzes
        '
        Me.lstQuizzes.FormattingEnabled = True
        Me.lstQuizzes.Location = New System.Drawing.Point(12, 33)
        Me.lstQuizzes.Name = "lstQuizzes"
        Me.lstQuizzes.Size = New System.Drawing.Size(148, 108)
        Me.lstQuizzes.TabIndex = 12
        '
        'pnlEditQuiz
        '
        Me.pnlEditQuiz.Controls.Add(Me.cmdHelp)
        Me.pnlEditQuiz.Controls.Add(Me.cmdSaveChanges)
        Me.pnlEditQuiz.Controls.Add(Me.picQuestionImage)
        Me.pnlEditQuiz.Controls.Add(Me.cmdAddNewQuestion)
        Me.pnlEditQuiz.Controls.Add(Me.lblChangeQuestionImage)
        Me.pnlEditQuiz.Controls.Add(Me.txtChangeQuestionText)
        Me.pnlEditQuiz.Controls.Add(Me.lblChangeQuestionText)
        Me.pnlEditQuiz.Controls.Add(Me.cmdDeleteQuestion)
        Me.pnlEditQuiz.Controls.Add(Me.Label3)
        Me.pnlEditQuiz.Controls.Add(Me.Label2)
        Me.pnlEditQuiz.Controls.Add(Me.lstQuestions)
        Me.pnlEditQuiz.Location = New System.Drawing.Point(10, 81)
        Me.pnlEditQuiz.Name = "pnlEditQuiz"
        Me.pnlEditQuiz.Size = New System.Drawing.Size(475, 159)
        Me.pnlEditQuiz.TabIndex = 15
        '
        'cmdSaveChanges
        '
        Me.cmdSaveChanges.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSaveChanges.Location = New System.Drawing.Point(319, 102)
        Me.cmdSaveChanges.Name = "cmdSaveChanges"
        Me.cmdSaveChanges.Size = New System.Drawing.Size(144, 23)
        Me.cmdSaveChanges.TabIndex = 23
        Me.cmdSaveChanges.Text = "Save Changes"
        Me.cmdSaveChanges.UseVisualStyleBackColor = True
        '
        'picQuestionImage
        '
        Me.picQuestionImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picQuestionImage.Location = New System.Drawing.Point(177, 82)
        Me.picQuestionImage.Name = "picQuestionImage"
        Me.picQuestionImage.Size = New System.Drawing.Size(128, 71)
        Me.picQuestionImage.TabIndex = 22
        Me.picQuestionImage.TabStop = False
        '
        'cmdAddNewQuestion
        '
        Me.cmdAddNewQuestion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddNewQuestion.Location = New System.Drawing.Point(169, 8)
        Me.cmdAddNewQuestion.Name = "cmdAddNewQuestion"
        Me.cmdAddNewQuestion.Size = New System.Drawing.Size(144, 23)
        Me.cmdAddNewQuestion.TabIndex = 21
        Me.cmdAddNewQuestion.Text = "Add New Question"
        Me.cmdAddNewQuestion.UseVisualStyleBackColor = True
        '
        'lblChangeQuestionImage
        '
        Me.lblChangeQuestionImage.AutoSize = True
        Me.lblChangeQuestionImage.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChangeQuestionImage.Location = New System.Drawing.Point(174, 66)
        Me.lblChangeQuestionImage.Name = "lblChangeQuestionImage"
        Me.lblChangeQuestionImage.Size = New System.Drawing.Size(142, 13)
        Me.lblChangeQuestionImage.TabIndex = 20
        Me.lblChangeQuestionImage.Text = "Change Question Image"
        '
        'txtChangeQuestionText
        '
        Me.txtChangeQuestionText.Location = New System.Drawing.Point(317, 41)
        Me.txtChangeQuestionText.Name = "txtChangeQuestionText"
        Me.txtChangeQuestionText.Size = New System.Drawing.Size(146, 20)
        Me.txtChangeQuestionText.TabIndex = 19
        '
        'lblChangeQuestionText
        '
        Me.lblChangeQuestionText.AutoSize = True
        Me.lblChangeQuestionText.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChangeQuestionText.Location = New System.Drawing.Point(184, 43)
        Me.lblChangeQuestionText.Name = "lblChangeQuestionText"
        Me.lblChangeQuestionText.Size = New System.Drawing.Size(133, 13)
        Me.lblChangeQuestionText.TabIndex = 18
        Me.lblChangeQuestionText.Text = "Change Question Text"
        '
        'cmdDeleteQuestion
        '
        Me.cmdDeleteQuestion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDeleteQuestion.Location = New System.Drawing.Point(319, 8)
        Me.cmdDeleteQuestion.Name = "cmdDeleteQuestion"
        Me.cmdDeleteQuestion.Size = New System.Drawing.Size(144, 23)
        Me.cmdDeleteQuestion.TabIndex = 17
        Me.cmdDeleteQuestion.Text = "Delete Question"
        Me.cmdDeleteQuestion.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(14, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(146, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Select a question to edit"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(26, -44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(121, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Select a quiz to edit"
        '
        'lstQuestions
        '
        Me.lstQuestions.FormattingEnabled = True
        Me.lstQuestions.Location = New System.Drawing.Point(17, 35)
        Me.lstQuestions.Name = "lstQuestions"
        Me.lstQuestions.Size = New System.Drawing.Size(148, 82)
        Me.lstQuestions.TabIndex = 14
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'cmdBack
        '
        Me.cmdBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBack.Location = New System.Drawing.Point(4, 231)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.Size = New System.Drawing.Size(46, 40)
        Me.cmdBack.TabIndex = 77
        Me.cmdBack.Text = "<"
        Me.cmdBack.UseVisualStyleBackColor = True
        '
        'cmdHelp
        '
        Me.cmdHelp.Location = New System.Drawing.Point(-6, 125)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.Size = New System.Drawing.Size(42, 20)
        Me.cmdHelp.TabIndex = 78
        Me.cmdHelp.Text = "Help"
        Me.cmdHelp.UseVisualStyleBackColor = True
        '
        'frmAdminQuizMgmt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 273)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.pnlEditQuiz)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.picLogo)
        Me.Controls.Add(Me.pnlQuizSelection)
        Me.Name = "frmAdminQuizMgmt"
        Me.Text = "frm"
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlQuizSelection.ResumeLayout(False)
        Me.pnlQuizSelection.PerformLayout()
        Me.pnlEditQuiz.ResumeLayout(False)
        Me.pnlEditQuiz.PerformLayout()
        CType(Me.picQuestionImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picLogo As System.Windows.Forms.PictureBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblWelcome As System.Windows.Forms.Label
    Friend WithEvents pnlQuizSelection As System.Windows.Forms.Panel
    Friend WithEvents cmdSaveNewQuiz As System.Windows.Forms.Button
    Friend WithEvents lblEnterNewQuizName As System.Windows.Forms.Label
    Friend WithEvents txtNewQuizName As System.Windows.Forms.TextBox
    Friend WithEvents cmdAddNewQuiz As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lstQuizzes As System.Windows.Forms.ListBox
    Friend WithEvents pnlEditQuiz As System.Windows.Forms.Panel
    Friend WithEvents cmdSaveChanges As System.Windows.Forms.Button
    Friend WithEvents picQuestionImage As System.Windows.Forms.PictureBox
    Friend WithEvents cmdAddNewQuestion As System.Windows.Forms.Button
    Friend WithEvents lblChangeQuestionImage As System.Windows.Forms.Label
    Friend WithEvents txtChangeQuestionText As System.Windows.Forms.TextBox
    Friend WithEvents lblChangeQuestionText As System.Windows.Forms.Label
    Friend WithEvents cmdDeleteQuestion As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lstQuestions As System.Windows.Forms.ListBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents cmdBack As System.Windows.Forms.Button
    Friend WithEvents cmdHelp As System.Windows.Forms.Button
End Class
