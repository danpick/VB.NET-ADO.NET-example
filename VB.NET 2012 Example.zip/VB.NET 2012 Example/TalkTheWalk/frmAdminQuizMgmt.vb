﻿Public Class frmAdminQuizMgmt

    Dim mbInsertMode As Boolean
    Dim miAreaID As Integer
    Dim miQuestionID As Integer
    Dim mbImageChanged As Boolean
    
    Private Sub frmAdminQuizMgmt_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        frmAdmin.Show()
    End Sub

    Private Sub frmAdminQuizMgmt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        LoadGenericFormSettings(Me)

        'picLogo.Left = 10
        'picLogo.Top = 10
        'lblTitle.Left = 135
        'lblTitle.Top = 10
        'lblWelcome.Left = 335
        'lblWelcome.Top = 10

        lblWelcome.Text = gsWelcomeText
        lblTitle.Text = "Quiz Management"
        pnlQuizSelection.Visible = True
        pnlEditQuiz.Visible = False
        cmdAddNewQuiz.Visible = False
        lblEnterNewQuizName.Visible = False
        txtNewQuizName.Visible = False
        cmdSaveNewQuiz.Visible = False
        picQuestionImage.SizeMode = PictureBoxSizeMode.StretchImage

        LoadQuizSelectionList()

    End Sub


    Private Sub lstQuizzes_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstQuizzes.SelectedIndexChanged

        LoadQuestions()

    End Sub

    Private Sub LoadQuestions()

        Dim sSQL As String
        Dim iAreaSelected As Integer = CType(lstQuizzes.SelectedItem, ValueDescriptionPair).Value
        Dim iQuestionID As Integer
        Dim sQuestionText As String

        pnlQuizSelection.Visible = False
        pnlEditQuiz.Visible = True

        sSQL = "SELECT niQuestionID, tQuestionText FROM tblQuestions WHERE niAreaID =" & iAreaSelected & " ORDER BY tQuestionText ASC"
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "Questions")

        lstQuestions.Items.Clear()
        For i = 0 To gdsData.Tables("Questions").Rows.Count - 1
            iQuestionID = gdsData.Tables("Questions").Rows(i).Item("niQuestionID")
            sQuestionText = gdsData.Tables("Questions").Rows(i).Item("tQuestionText")
            lstQuestions.Items.Add(New ValueDescriptionPair(iQuestionID, sQuestionText))
        Next i
        gdsData.Tables("Questions").Clear()

        cmdDeleteQuestion.Visible = False
        lblChangeQuestionText.Visible = False
        txtChangeQuestionText.Visible = False
        lblChangeQuestionImage.Visible = False
        picQuestionImage.Visible = False
        cmdSaveChanges.Visible = False
        mbInsertMode = False

    End Sub

    Private Sub LoadQuizSelectionList()

        Dim sSQL As String

        Dim sAreaName As String

        sSQL = "SELECT niAreaID, tAreaName FROM tblAreas ORDER BY tAreaName ASC"
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "Areas")

        lstQuizzes.Items.Clear()
        For i = 0 To gdsData.Tables("Areas").Rows.Count - 1
            miAreaID = gdsData.Tables("Areas").Rows(i).Item("niAreaID")
            sAreaName = gdsData.Tables("Areas").Rows(i).Item("tAreaName")
            lstQuizzes.Items.Add(New ValueDescriptionPair(miAreaID, sAreaName))
        Next i

        gdsData.Tables("Areas").Reset()

    End Sub

    Private Sub lstQuestions_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstQuestions.SelectedIndexChanged

        LoadQuestion()

    End Sub

    Private Sub LoadQuestion()

        Dim sQuestionID As String
        Dim sTempImageFileName As String

        mbImageChanged = False
        cmdDeleteQuestion.Visible = True
        lblChangeQuestionText.Visible = True
        txtChangeQuestionText.Visible = True
        txtChangeQuestionText.Text = CType(lstQuestions.SelectedItem, ValueDescriptionPair).Description
        lblChangeQuestionImage.Visible = True
        picQuestionImage.Visible = True
        cmdSaveChanges.Visible = True

        miQuestionID = CType(lstQuestions.SelectedItem, ValueDescriptionPair).Value

        sQuestionID = Format(miQuestionID, "000")

        'don't display the actual existing image as this would lock the image file
        'and we might need to rename/delete the existing image if replacing it
        'so copy file and display copy in picturebox, so no lock placed on actual file
        sTempImageFileName = gsAppPath & "\" & Format(miAreaID, "000") & "\" & sQuestionID & ".COPY"
        My.Computer.FileSystem.CopyFile(gsAppPath & "\" & Format(miAreaID, "000") & "\" & sQuestionID & ".png", sTempImageFileName)
        picQuestionImage.Image = Image.FromFile(sTempImageFileName)

    End Sub

    Private Sub cmdAddNewQuestion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddNewQuestion.Click

        SetUpAddingNewQuestion()

    End Sub

    Private Sub SetUpAddingNewQuestion()

        mbInsertMode = True
        cmdDeleteQuestion.Visible = True
        lblChangeQuestionText.Visible = True
        txtChangeQuestionText.Visible = True
        txtChangeQuestionText.Text = ""
        lblChangeQuestionImage.Visible = True
        picQuestionImage.Visible = True
        picQuestionImage.Image = Nothing
        cmdSaveChanges.Visible = True

    End Sub

    Private Sub cmdSaveChanges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveChanges.Click

        SaveQuestion()

    End Sub

    Private Sub SaveQuestion()

        Dim sSQL As String
        Dim cmd As OleDb.OleDbCommand 'required locally
        Dim sNewImageFileName As String

        If mbInsertMode = True Then
            If mbImageChanged Then 'validate picture
                'user has selected picture
                sSQL = "INSERT INTO tblQuestions VALUES("
                sSQL = sSQL & iGetNextID("tblQuestions", "niQuestionID") & ", "
                sSQL = sSQL & miAreaID & ", "
                sSQL = sSQL & "'" & txtChangeQuestionText.Text & "', "
                sSQL = sSQL & "No, "
                sSQL = sSQL & "No)"
                cmd = New OleDb.OleDbCommand(sSQL, gCon)
                cmd.ExecuteNonQuery()

                sNewImageFileName = Application.StartupPath & "\"
                sNewImageFileName = sNewImageFileName & Format(miAreaID, "000") & "\"
                sNewImageFileName = sNewImageFileName & Format(iGetNextID("tblQuestions", "niQuestionID"), "000") & ".png"

                'picture saved into correct folder with iGetNextID as filename
                picQuestionImage.Image.Save(sNewImageFileName, System.Drawing.Imaging.ImageFormat.Png)

                MsgBox("New Question Added")
                LoadQuestions()
            Else
                MsgBox("Please select an image for this hill/mountain", MsgBoxStyle.Exclamation)
            End If
        Else

            'validate picture
            'user has not changed picture : do nothing re - picture
            'user has changed picture: overwrite existing stored image with new

            sSQL = "UPDATE tblQuestions SET "
            sSQL = sSQL & "tQuestionText = '" & txtChangeQuestionText.Text & "' "
            sSQL = sSQL & "WHERE niAreaID = " & miAreaID & " "
            sSQL = sSQL & "AND niQuestionID = " & miQuestionID
            cmd = New OleDb.OleDbCommand(sSQL, gCon)
            cmd.ExecuteNonQuery()

            sNewImageFileName = Application.StartupPath & "\"
            sNewImageFileName = sNewImageFileName & Format(miAreaID, "000") & "\"
            sNewImageFileName = sNewImageFileName & Format(miQuestionID, "000") & ".png"

            'picture saved into correct folder with same ID as filename
            If mbImageChanged Then
                'rename existing image for this question with extension .OLD
                My.Computer.FileSystem.RenameFile(sNewImageFileName, Format(miQuestionID, "000") & ".OLD")
                'save chosen image in place of existing (.OLD) image
                picQuestionImage.Image.Save(sNewImageFileName, System.Drawing.Imaging.ImageFormat.Png)
            End If
            MsgBox("Change saved")
            LoadQuestions()
        End If

    End Sub

    Private Sub picQuestionImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picQuestionImage.Click

        ChooseImageFile()


    End Sub

    Private Sub ChooseImageFile()

        If OpenFileDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            picQuestionImage.Image = Nothing
            picQuestionImage.Image = Image.FromFile(OpenFileDialog1.FileName)
            mbImageChanged = True
        End If

    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click

        Me.Close()

    End Sub

    Private Sub cmdDeleteQuestion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDeleteQuestion.Click

        DeleteQuestion()

    End Sub

    Private Sub DeleteQuestion()

        Dim sSQL As String
        Dim cmd As OleDb.OleDbCommand 'required locally

        sSQL = "DELETE FROM tblQuestions "
        sSQL = sSQL & "WHERE niAreaID = " & miAreaID & " "
        sSQL = sSQL & "AND niQuestionID = " & miQuestionID
        cmd = New OleDb.OleDbCommand(sSQL, gCon)
        cmd.ExecuteNonQuery()

        My.Computer.FileSystem.DeleteFile(gsAppPath & "\" & Format(miAreaID, "000") & "\" & Format(miQuestionID, "000") & ".png")

        MsgBox("Question Deleted")

        LoadQuestions()

    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class