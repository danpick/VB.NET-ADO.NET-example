﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminUserMgmt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAdminUserMgmt))
        Me.picLogo = New System.Windows.Forms.PictureBox
        Me.lblTitle = New System.Windows.Forms.Label
        Me.lblWelcome = New System.Windows.Forms.Label
        Me.pnlUpdateUser = New System.Windows.Forms.Panel
        Me.cmdBack = New System.Windows.Forms.Button
        Me.txtUsername = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmdCancel = New System.Windows.Forms.Button
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.cmdSave = New System.Windows.Forms.Button
        Me.txtEmailAddress = New System.Windows.Forms.TextBox
        Me.txtLastName = New System.Windows.Forms.TextBox
        Me.txtFirstName = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.pnlUserSelection = New System.Windows.Forms.Panel
        Me.cmdBack2 = New System.Windows.Forms.Button
        Me.txtLastNameSearch = New System.Windows.Forms.TextBox
        Me.txtEmailSearch = New System.Windows.Forms.TextBox
        Me.lstSearchResults = New System.Windows.Forms.ListBox
        Me.txtUsernameSearch = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.cmdAddNewUser = New System.Windows.Forms.Button
        Me.cmdHelp = New System.Windows.Forms.Button
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlUpdateUser.SuspendLayout()
        Me.pnlUserSelection.SuspendLayout()
        Me.SuspendLayout()
        '
        'picLogo
        '
        Me.picLogo.Image = CType(resources.GetObject("picLogo.Image"), System.Drawing.Image)
        Me.picLogo.Location = New System.Drawing.Point(4, 4)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(40, 40)
        Me.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLogo.TabIndex = 4
        Me.picLogo.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(134, -4)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(193, 64)
        Me.lblTitle.TabIndex = 5
        Me.lblTitle.Text = "Label1"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblWelcome
        '
        Me.lblWelcome.Location = New System.Drawing.Point(335, 10)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(150, 64)
        Me.lblWelcome.TabIndex = 8
        Me.lblWelcome.Text = "Welcome"
        Me.lblWelcome.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'pnlUpdateUser
        '
        Me.pnlUpdateUser.Controls.Add(Me.cmdHelp)
        Me.pnlUpdateUser.Controls.Add(Me.cmdBack)
        Me.pnlUpdateUser.Controls.Add(Me.txtUsername)
        Me.pnlUpdateUser.Controls.Add(Me.Label1)
        Me.pnlUpdateUser.Controls.Add(Me.cmdCancel)
        Me.pnlUpdateUser.Controls.Add(Me.txtPassword)
        Me.pnlUpdateUser.Controls.Add(Me.cmdSave)
        Me.pnlUpdateUser.Controls.Add(Me.txtEmailAddress)
        Me.pnlUpdateUser.Controls.Add(Me.txtLastName)
        Me.pnlUpdateUser.Controls.Add(Me.txtFirstName)
        Me.pnlUpdateUser.Controls.Add(Me.Label5)
        Me.pnlUpdateUser.Controls.Add(Me.Label4)
        Me.pnlUpdateUser.Controls.Add(Me.Label3)
        Me.pnlUpdateUser.Controls.Add(Me.Label2)
        Me.pnlUpdateUser.Location = New System.Drawing.Point(12, 63)
        Me.pnlUpdateUser.Name = "pnlUpdateUser"
        Me.pnlUpdateUser.Size = New System.Drawing.Size(435, 204)
        Me.pnlUpdateUser.TabIndex = 60
        '
        'cmdBack
        '
        Me.cmdBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBack.Location = New System.Drawing.Point(0, 164)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.Size = New System.Drawing.Size(46, 40)
        Me.cmdBack.TabIndex = 76
        Me.cmdBack.Text = "<"
        Me.cmdBack.UseVisualStyleBackColor = True
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(82, 6)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(150, 20)
        Me.txtUsername.TabIndex = 75
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(10, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 74
        Me.Label1.Text = "Username:"
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(365, 142)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(65, 54)
        Me.cmdCancel.TabIndex = 73
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(82, 107)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(150, 20)
        Me.txtPassword.TabIndex = 78
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(269, 142)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(90, 54)
        Me.cmdSave.TabIndex = 68
        Me.cmdSave.Text = "Save Changes"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'txtEmailAddress
        '
        Me.txtEmailAddress.Location = New System.Drawing.Point(82, 139)
        Me.txtEmailAddress.Name = "txtEmailAddress"
        Me.txtEmailAddress.Size = New System.Drawing.Size(150, 20)
        Me.txtEmailAddress.TabIndex = 79
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(81, 73)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(150, 20)
        Me.txtLastName.TabIndex = 77
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(82, 39)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(150, 20)
        Me.txtFirstName.TabIndex = 76
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(34, 142)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 13)
        Me.Label5.TabIndex = 63
        Me.Label5.Text = "Email:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(10, 109)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 62
        Me.Label4.Text = "Password:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 76)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 61
        Me.Label3.Text = "Last Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(4, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 13)
        Me.Label2.TabIndex = 60
        Me.Label2.Text = "First Name:"
        '
        'pnlUserSelection
        '
        Me.pnlUserSelection.Controls.Add(Me.cmdBack2)
        Me.pnlUserSelection.Controls.Add(Me.txtLastNameSearch)
        Me.pnlUserSelection.Controls.Add(Me.txtEmailSearch)
        Me.pnlUserSelection.Controls.Add(Me.lstSearchResults)
        Me.pnlUserSelection.Controls.Add(Me.txtUsernameSearch)
        Me.pnlUserSelection.Controls.Add(Me.Label8)
        Me.pnlUserSelection.Controls.Add(Me.Label7)
        Me.pnlUserSelection.Controls.Add(Me.Label6)
        Me.pnlUserSelection.Controls.Add(Me.cmdAddNewUser)
        Me.pnlUserSelection.Location = New System.Drawing.Point(4, 71)
        Me.pnlUserSelection.Name = "pnlUserSelection"
        Me.pnlUserSelection.Size = New System.Drawing.Size(464, 190)
        Me.pnlUserSelection.TabIndex = 62
        '
        'cmdBack2
        '
        Me.cmdBack2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBack2.Location = New System.Drawing.Point(7, 158)
        Me.cmdBack2.Name = "cmdBack2"
        Me.cmdBack2.Size = New System.Drawing.Size(46, 24)
        Me.cmdBack2.TabIndex = 77
        Me.cmdBack2.Text = "<"
        Me.cmdBack2.UseVisualStyleBackColor = True
        '
        'txtLastNameSearch
        '
        Me.txtLastNameSearch.Location = New System.Drawing.Point(309, 19)
        Me.txtLastNameSearch.Name = "txtLastNameSearch"
        Me.txtLastNameSearch.Size = New System.Drawing.Size(118, 20)
        Me.txtLastNameSearch.TabIndex = 7
        '
        'txtEmailSearch
        '
        Me.txtEmailSearch.Location = New System.Drawing.Point(162, 19)
        Me.txtEmailSearch.Name = "txtEmailSearch"
        Me.txtEmailSearch.Size = New System.Drawing.Size(118, 20)
        Me.txtEmailSearch.TabIndex = 6
        '
        'lstSearchResults
        '
        Me.lstSearchResults.FormattingEnabled = True
        Me.lstSearchResults.Location = New System.Drawing.Point(9, 44)
        Me.lstSearchResults.Name = "lstSearchResults"
        Me.lstSearchResults.Size = New System.Drawing.Size(425, 108)
        Me.lstSearchResults.TabIndex = 5
        '
        'txtUsernameSearch
        '
        Me.txtUsernameSearch.Location = New System.Drawing.Point(7, 19)
        Me.txtUsernameSearch.Name = "txtUsernameSearch"
        Me.txtUsernameSearch.Size = New System.Drawing.Size(118, 20)
        Me.txtUsernameSearch.TabIndex = 4
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(306, 2)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(128, 13)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Search by Last Name"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(159, 2)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(98, 13)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Search by Email"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(2, 2)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(124, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Search by Username"
        '
        'cmdAddNewUser
        '
        Me.cmdAddNewUser.Location = New System.Drawing.Point(126, 160)
        Me.cmdAddNewUser.Name = "cmdAddNewUser"
        Me.cmdAddNewUser.Size = New System.Drawing.Size(164, 24)
        Me.cmdAddNewUser.TabIndex = 0
        Me.cmdAddNewUser.Text = "Add New User"
        Me.cmdAddNewUser.UseVisualStyleBackColor = True
        '
        'cmdHelp
        '
        Me.cmdHelp.Location = New System.Drawing.Point(-8, 142)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.Size = New System.Drawing.Size(42, 20)
        Me.cmdHelp.TabIndex = 63
        Me.cmdHelp.Text = "Help"
        Me.cmdHelp.UseVisualStyleBackColor = True
        '
        'frmAdminUserMgmt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 273)
        Me.Controls.Add(Me.pnlUpdateUser)
        Me.Controls.Add(Me.pnlUserSelection)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.picLogo)
        Me.Name = "frmAdminUserMgmt"
        Me.Text = "frm"
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlUpdateUser.ResumeLayout(False)
        Me.pnlUpdateUser.PerformLayout()
        Me.pnlUserSelection.ResumeLayout(False)
        Me.pnlUserSelection.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picLogo As System.Windows.Forms.PictureBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblWelcome As System.Windows.Forms.Label
    Friend WithEvents pnlUpdateUser As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents txtEmailAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents cmdBack As System.Windows.Forms.Button
    Friend WithEvents pnlUserSelection As System.Windows.Forms.Panel
    Friend WithEvents cmdBack2 As System.Windows.Forms.Button
    Friend WithEvents txtLastNameSearch As System.Windows.Forms.TextBox
    Friend WithEvents txtEmailSearch As System.Windows.Forms.TextBox
    Friend WithEvents lstSearchResults As System.Windows.Forms.ListBox
    Friend WithEvents txtUsernameSearch As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmdAddNewUser As System.Windows.Forms.Button
    Friend WithEvents cmdHelp As System.Windows.Forms.Button
End Class
