﻿Public Class frmAdminUserMgmt

    Dim msUsername As String
    Dim mbInsertMode As Boolean

    Private Sub frmAdminUserMgmt_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        frmAdmin.Show()

    End Sub

    Private Sub frmAdminUserMgmt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        LoadGenericFormSettings(Me)

        'picLogo.Left = 10
        'picLogo.Top = 10
        'lblTitle.Left = 135
        'lblTitle.Top = 10
        'lblWelcome.Left = 335
        'lblWelcome.Top = 10

        lblWelcome.Text = gsWelcomeText
        lblTitle.Text = "User Management"
        pnlUserSelection.Visible = True
        pnlUpdateUser.Visible = False

    End Sub

    Private Sub UserSearch(ByVal sWildcard As String)

        Dim sSQL As String
        Dim sResult As String

        sSQL = "SELECT tUserName, "
        sSQL = sSQL & "tFirstName, "
        sSQL = sSQL & "tLastName, "
        sSQL = sSQL & "tEmailAddress "
        sSQL = sSQL & "FROM tblUsers "
        sSQL = sSQL & "WHERE tUserName Like '" + sWildcard + "%'"
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "UserSearch")

        lstSearchResults.Items.Clear()
        For i = 0 To gdsData.Tables("UserSearch").Rows.Count - 1
            sResult = gdsData.Tables("UserSearch").Rows(i).Item("tUserName") & " ("
            sResult = sResult & gdsData.Tables("UserSearch").Rows(i).Item("tFirstName") & " "
            sResult = sResult & gdsData.Tables("UserSearch").Rows(i).Item("tLastName") & ", "
            sResult = sResult & gdsData.Tables("UserSearch").Rows(i).Item("tEmailAddress") & ")"

            lstSearchResults.Items.Add(New ValueDescriptionPair(gdsData.Tables("UserSearch").Rows(i).Item("tUserName"), sResult))

        Next i

        gdsData.Tables("UserSearch").Reset()

    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        SaveUser()

    End Sub

    Private Sub SaveUser()

        Dim sSQL As String
        Dim cmd As OleDb.OleDbCommand
        Dim sValidationErrorMessage = ""

        If txtUsername.Text = "" Then
            sValidationErrorMessage = sValidationErrorMessage & "Please enter a Username" & vbNewLine
        End If
        If txtFirstName.Text = "" Then
            sValidationErrorMessage = sValidationErrorMessage & "Please enter a First Name" & vbNewLine
        End If
        If txtLastName.Text = "" Then
            sValidationErrorMessage = sValidationErrorMessage & "Please enter a Last Name" & vbNewLine
        End If
        If txtEmailAddress.Text = "" Then 'could be developed further to strictly validate email address
            sValidationErrorMessage = sValidationErrorMessage & "Please enter an EmailAddress" & vbNewLine
        End If

        If sValidationErrorMessage = "" Then
            If mbInsertMode = False Then
                sSQL = "UPDATE tblUsers SET "
                sSQL = sSQL & "tUserName = '" & txtUsername.Text & "', "
                sSQL = sSQL & "tFirstName = '" & txtFirstName.Text & "', "
                sSQL = sSQL & "tLastName = '" & txtLastName.Text & "', "
                sSQL = sSQL & "tUserPassword = '" & txtPassword.Text & "', "
                sSQL = sSQL & "tEmailAddress = '" & txtEmailAddress.Text & "' "
                sSQL = sSQL & "WHERE tUsername = '" & msUsername & "'"
                cmd = New OleDb.OleDbCommand(sSQL, gCon)
                cmd.ExecuteNonQuery()

                msUsername = txtUsername.Text

                MsgBox("Account Settings Updated")
            Else
                sSQL = "INSERT INTO tblUsers VALUES("
                sSQL = sSQL & "'" & txtUsername.Text & "', " 'nothing to validate for non-exisiting username - error
                sSQL = sSQL & "'" & txtPassword.Text & "', "
                sSQL = sSQL & "'" & txtFirstName.Text & "', "
                sSQL = sSQL & "'" & txtLastName.Text & "', "
                sSQL = sSQL & "'" & txtEmailAddress.Text & "', "
                sSQL = sSQL & "No)"
                cmd = New OleDb.OleDbCommand(sSQL, gCon)
                cmd.ExecuteNonQuery()

                MsgBox("New User Created")
            End If
            cmdSave.Enabled = False
        Else
            MsgBox(sValidationErrorMessage, MsgBoxStyle.Exclamation)
        End If

    End Sub

    Private Sub txtUsername_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtUsername.TextChanged
        cmdSave.Enabled = True
        cmdCancel.Enabled = True
    End Sub

    Private Sub txtFirstName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFirstName.TextChanged
        cmdSave.Enabled = True
        cmdCancel.Enabled = True
    End Sub

    Private Sub txtLastName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLastName.TextChanged
        cmdSave.Enabled = True
        cmdCancel.Enabled = True
    End Sub

    Private Sub txtPassword_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPassword.TextChanged
        cmdSave.Enabled = True
        cmdCancel.Enabled = True
    End Sub

    Private Sub txtEmailAddress_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtEmailAddress.TextChanged
        cmdSave.Enabled = True
        cmdCancel.Enabled = True
    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click

        pnlUpdateUser.Visible = False
        txtUsernameSearch.Text = ""
        txtEmailSearch.Text = ""
        txtLastNameSearch.Text = ""
        lstSearchResults.Items.Clear()
        pnlUserSelection.Visible = True

    End Sub

    Private Sub cmdAddNewUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddNewUser.Click
        pnlUpdateUser.Visible = True
        pnlUserSelection.Visible = False
        mbInsertMode = True
    End Sub

    Private Sub txtUsernameSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtUsernameSearch.TextChanged
        txtEmailSearch.Text = ""
        txtLastNameSearch.Text = ""
        UserSearch(txtUsernameSearch.Text)
    End Sub

    Private Sub txtEmailSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtEmailSearch.TextChanged
        txtUsernameSearch.Text = ""
        txtLastNameSearch.Text = ""
        UserSearch(txtEmailSearch.Text)
    End Sub

    Private Sub txtLastNameSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLastNameSearch.TextChanged
        txtEmailSearch.Text = ""
        txtUsernameSearch.Text = ""
        UserSearch(txtLastNameSearch.Text)
    End Sub

    Private Sub lstSearchResults_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstSearchResults.SelectedIndexChanged

        LoadUser()

    End Sub

    Private Sub LoadUser()

        Dim sSQL As String
        msUsername = CType(lstSearchResults.SelectedItem, ValueDescriptionPair).Value
        mbInsertMode = False

        pnlUserSelection.Visible = False
        pnlUpdateUser.Visible = True

        sSQL = "SELECT tUserName, "
        sSQL = sSQL & "tFirstName, "
        sSQL = sSQL & "tLastName, "
        sSQL = sSQL & "tUserPassword, "
        sSQL = sSQL & "tEmailAddress "
        sSQL = sSQL & "FROM tblUsers "
        sSQL = sSQL & "WHERE tUserName = '" & msUsername & "'"
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "UserToUpdate")

        txtUsername.Text = gdsData.Tables("UserToUpdate").Rows(0).Item("tUserName")
        txtFirstName.Text = gdsData.Tables("UserToUpdate").Rows(0).Item("tFirstName")
        txtLastName.Text = gdsData.Tables("UserToUpdate").Rows(0).Item("tLastName")
        txtPassword.Text = gdsData.Tables("UserToUpdate").Rows(0).Item("tUserPassword")
        txtEmailAddress.Text = gdsData.Tables("UserToUpdate").Rows(0).Item("tEmailAddress")
        txtUsername.Focus()
        gdsData.Tables("UserToUpdate").Reset()

    End Sub

    Private Sub cmdBack2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack2.Click
        frmAdmin.Show()
        Me.Hide()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        LoadUser()
    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class