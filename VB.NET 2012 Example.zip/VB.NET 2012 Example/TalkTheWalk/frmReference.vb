﻿Public Class frmReference

    Dim miAreaSelected As Integer

    Private Sub frmReference_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        LoadGenericFormSettings(Me)

        'picLogo.Left = 10
        'picLogo.Top = 10
        'lblTitle.Left = 135
        'lblTitle.Top = 10
        'lblWelcome.Left = 335
        'lblWelcome.Top = 10

        lblWelcome.Text = gsWelcomeText
        lblTitle.Text = "Reference"
        txtRefSearch.Enabled = False
        picRef.SizeMode = PictureBoxSizeMode.StretchImage

        gPopulateAreasCombo(Me)

    End Sub

    Private Sub cboAreas_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboAreas.SelectedIndexChanged

        PopulateHillsMountains()

    End Sub

    Private Sub lstRefResults_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstRefResults.SelectedIndexChanged

        PopulateHillsMountainImage()

    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click

        Me.Close()

    End Sub

    Private Sub frmReference_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        frmUser.Show()

    End Sub

    Private Sub txtRefSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRefSearch.TextChanged

        SearchHillsMountains()

    End Sub



    Private Sub PopulateHillsMountains()

        Dim sSQL As String
        Dim iQuestionID As Integer
        Dim sQuestionText As String

        miAreaSelected = CType(cboAreas.SelectedItem, ValueDescriptionPair).Value

        sSQL = "SELECT niQuestionID, "
        sSQL = sSQL & "tQuestionText "
        sSQL = sSQL & "FROM tblQuestions "
        sSQL = sSQL & "WHERE niAreaID = " & miAreaSelected & " " 'will error if no database entries/images for selected area
        sSQL = sSQL & "ORDER BY tQuestionText ASC"
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "Reference")

        picRef.Image = Nothing
        lstRefResults.Items.Clear()
        For i = 0 To gdsData.Tables("Reference").Rows.Count - 1
            iQuestionID = gdsData.Tables("Reference").Rows(i).Item("niQuestionID")
            sQuestionText = gdsData.Tables("Reference").Rows(i).Item("tQuestionText")
            lstRefResults.Items.Add(New ValueDescriptionPair(iQuestionID, sQuestionText))
        Next i
        gdsData.Tables("Reference").Reset()

        txtRefSearch.Enabled = True

    End Sub

    Private Sub PopulateHillsMountainImage()

        Dim sQuestionID As String

        sQuestionID = Format(CType(lstRefResults.SelectedItem, ValueDescriptionPair).Value, "000")

        picRef.Image = Image.FromFile(gsAppPath & "\" & Format(miAreaSelected, "000") & "\" & sQuestionID & ".png")

    End Sub

    Private Sub SearchHillsMountains()

        Dim sSQL As String
        Dim iID As Integer
        Dim sName As String

        sSQL = "SELECT niQuestionID, "
        sSQL = sSQL & "tQuestionText "
        sSQL = sSQL & "FROM tblQuestions "
        sSQL = sSQL & "WHERE tQuestionText Like '" + txtRefSearch.Text + "%' "
        sSQL = sSQL & "AND niAreaID = " & miAreaSelected
        gda = New OleDb.OleDbDataAdapter(sSQL, gCon)
        gda.Fill(gdsData, "RefSearch")

        lstRefResults.Items.Clear()
        For i = 0 To gdsData.Tables("RefSearch").Rows.Count - 1
            iID = gdsData.Tables("RefSearch").Rows(i).Item("niQuestionID")
            sName = gdsData.Tables("RefSearch").Rows(i).Item("tQuestionText")
            lstRefResults.Items.Add(New ValueDescriptionPair(iID, sName))
        Next i

        gdsData.Tables("RefSearch").Reset()

    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        gDisplayHelpMessage()

    End Sub
End Class